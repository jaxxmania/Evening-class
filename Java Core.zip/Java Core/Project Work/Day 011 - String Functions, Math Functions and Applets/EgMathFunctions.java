class EgMathFunctions
{
public static void main(String args[])
{
System.out.println(Math.pow(2,4));
System.out.println(Math.sqrt(121));
System.out.println(Math.abs(-14));
System.out.println(Math.cos(0));
}
}