import java.io.*;

class TicketReservation
	{
		int flightNumber;
		String date,time,destination;
		
	}

class Confirmed extends TicketReservation
	{
		int seatNumber;
		
		public void assign()
			{
				flightNumber=9876;
				date="27th Feb, 2011";
				time="3:00 AM";
				destination="Lisbon";
				seatNumber=12;
			}
		
		public void display()
			{
				System.out.println("Flight "+flightNumber+", On "+date+", At "+time+", To "+destination+", With seat number "+seatNumber);
			}
	}

class Requested extends TicketReservation
	{
		boolean status;
		
		public void assign()
			{
				flightNumber=9876;
				date="27th Feb, 2011";
				time="3:00 AM";
				destination="Lisbon";
				status=false;
			}
		
		public void display()
			{
				System.out.println("Flight "+flightNumber+", On "+date+", At "+time+", To "+destination+".\nAvailable : "+((status==false)?"No":"Yes"));
			}
	}

public class FlyHighAirlines
	{
		public static void main(String args[]) throws Exception
			{
				int choice;
				Confirmed c1=new Confirmed();
				Requested r1=new Requested();
				
				System.out.println("1. Confirmed Ticket\n2. Requested Ticket\n");
				
				BufferedReader bfr=new BufferedReader(new InputStreamReader(System.in));
				choice=Integer.parseInt(bfr.readLine());
				
				switch(choice)
					{
						case 1:
							c1.assign();
							c1.display();
							break;
						
						case 2:
							r1.assign();
							r1.display();
							break;
						
						default:
							System.out.println("Error.");
					}
			}
	}