import java.io.*;

class Applicant
	{
		String name,qualification,experiance;
		int age,applicantId;
		char gender;
		
	}

class Interviewer extends Applicant
	{
		//String candidate=name,this.age=age;
		//int candidateId=applicantId;
		int testScores,rating;		
	}

class Referral extends Interviewer
	{
		String empName;
		String referredName,position;
		int empId,referredId;
	}

public class SysSolInc extends Referral
	{
		public void extRec()
			{
				name="Harry";
				qualification="MBS";
				experiance="n/a";
				applicantId=12345;
				age=25;
				gender='M';
			}
		
		public void empRef()
			{
				empId=666;
				empName="John";
				referredId=999;
				referredName="Sally";
				position="Accountant";
			}
			
		public static void main (String args[]) throws Exception
			{
				int choice;
				SysSolInc temp=new SysSolInc();
				
				System.out.println("1. External Recruitment Process\n2. Employee Referral Process\n");
				
				BufferedReader bfr=new BufferedReader(new InputStreamReader(System.in));
				choice=Integer.parseInt(bfr.readLine());
				
				switch(choice)
					{
						case 1:
							temp.extRec();
							break;
							
						case 2:
							temp.empRef();
							break;
							
						default:
							System.out.println("Error.");
					}
								
				System.exit(0);
			}
	}