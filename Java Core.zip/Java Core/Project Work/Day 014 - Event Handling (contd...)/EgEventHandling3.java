import java.awt.*;
import java.applet.*;
import java.awt.event.*;

/*
<applet code="EgEventHandling3.class" width="400" height="400">
</applet>
*/

public class EgEventHandling3 extends Applet implements ActionListener,ItemListener
	{
		Label lblSource,lblDestination,lblChoice;
		TextField txtSource,txtDestination;
		Button btnSend;
		Choice c1;
		
		public void init()
			{
				setLayout(null);
				
				lblSource=new Label("Source");
				lblDestination=new Label("Destination");
				lblChoice=new Label("Choice");
				
				txtSource=new TextField(50);
				txtDestination=new TextField(50);
				
				btnSend=new Button("Send");
				
				c1=new Choice();
				
				add(lblSource);
				lblSource.setBounds(20,20,75,25);
				
				add(txtSource);
				txtSource.setBounds(100,20,75,25);
				
				add(btnSend);
				btnSend.setBounds(200,20,50,25);
				
				add(lblChoice);
				lblChoice.setBounds(20,55,75,25);
				
				add(c1);
				c1.setBounds(100,55,75,25);
				
				add(lblDestination);
				lblDestination.setBounds(20,85,75,25);
				
				add(txtDestination);
				txtDestination.setBounds(100,85,75,25);
				
				btnSend.addActionListener(this);
				c1.addItemListener(this);
			}
		
		public void actionPerformed(ActionEvent ae)
			{
				if(ae.getSource()==btnSend)
					{
						String s1=txtSource.getText();
						c1.add(s1);
						txtSource.setText("");
					}
			}
		
		public void itemStateChanged(ItemEvent ie)
			{
				if(ie.getSource()==c1)
					{
						txtDestination.setText(c1.getSelectedItem().toString());	//.toString() is optional
					}
			}
	}