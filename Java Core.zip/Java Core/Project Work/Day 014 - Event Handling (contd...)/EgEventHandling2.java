import java.awt.*;
import java.applet.*;
import java.awt.event.*;

/*
	<applet code="EgEventHandling2.class" width="400" height="400">
	</applet>
*/

public class EgEventHandling2 extends Applet implements ActionListener,ItemListener,MouseListener,MouseMotionListener
	{
		TextField messageField;
		TextArea commonArea;
		Checkbox c1,c2;
		Button btnSend;
		
		public void init()
			{
				setLayout(null);
				
				commonArea=new TextArea("",10,25);
				messageField=new TextField(25);
				c1=new Checkbox("Cricket");
				c2=new Checkbox("Hockey");
				btnSend=new Button("Send");
								
				add(commonArea);
				commonArea.setBounds(20,20,150,150);
				
				add(messageField);
				messageField.setBounds(20,200,150,25);
				
				add(btnSend);
				btnSend.setBounds(175,200,50,25);
				
				add(c1);
				c1.setBounds(20,250,75,25);
				
				add(c2);
				c2.setBounds(100,250,75,25);
				
				btnSend.addActionListener(this);
				c1.addItemListener(this);
				c2.addItemListener(this);
				addMouseListener(this);
				addMouseMotionListener(this);
			}
		
		public void actionPerformed(ActionEvent ae)
			{
				if(ae.getSource()==btnSend)
					{
						String s1=messageField.getText();
						String s2=commonArea.getText();
						commonArea.setText(s1+"\n"+s2);
						messageField.setText("");
					}
			}
		
		public void itemStateChanged(ItemEvent ie)
			{
				if(ie.getSource()==c1)
					{
						messageField.setText(c1.getLabel());
					}
					
				if(ie.getSource()==c2)
					{
						messageField.setText(c2.getLabel());
					}
			}
	
		public void mouseClicked(MouseEvent me)
			{
				showStatus("You just Clicked");
			}
	
		public void mouseMoved(MouseEvent me)
			{
				showStatus("Your Mouse Position is:"+me.getX()+" "+me.getY());
			}
	
		public void mouseDragged(MouseEvent me)
			{
				showStatus("Mouse Dragged");
			}

		public void mouseEntered(MouseEvent me)
			{
			}
		
		public void mouseReleased(MouseEvent me)
			{
			}
		
		public void mouseExited(MouseEvent me)
			{
				showStatus("Now your mouse is out of Applet");
			}
	
		public void mousePressed(MouseEvent me)
			{
				showStatus("Mouse Pressed");
			}
	}