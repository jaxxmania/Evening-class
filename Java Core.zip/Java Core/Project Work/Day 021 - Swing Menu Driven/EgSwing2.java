import javax.swing.*;
import java.awt.event.*;
import java.awt.*;

public class EgSwing2 extends JFrame implements ActionListener
	{
		JMenuBar mb;
		JMenu mFile,mEdit,mHelp;
		JMenuItem miNew,miOpen,miPrint,miCopy,miCut,miPaste,miSelectAll,miUndo,miRedo,miAbout;
		
		JToolBar tbFile;
		JButton btnNew,btnOpen,btnPrint;
		
		public EgSwing2()
			{
				mb=new JMenuBar();
				
				mFile=new JMenu("File");
				mEdit=new JMenu("Edit");
				mHelp=new JMenu("Help");
				
				miNew=new JMenuItem("New");
				miOpen=new JMenuItem("Open");
				miPrint=new JMenuItem("Print");
				miCopy=new JMenuItem("Copy");
				miCut=new JMenuItem("Cut");
				miPaste=new JMenuItem("Paste");
				
				miSelectAll=new JMenuItem("Select All");
				miUndo=new JMenuItem("Undo");
				miRedo=new JMenuItem("Redo");
				miAbout=new JMenuItem("About");
				
				setJMenuBar(mb);
				mb.add(mFile);
				mb.add(mEdit);
				mb.add(mHelp);
								
				mFile.add(miNew);
				mFile.add(miOpen);
				mFile.add(miPrint);
				mEdit.add(miCopy);
				mEdit.add(miCut);
				mEdit.add(miPaste);
				mEdit.addSeparator();
				mEdit.add(miSelectAll);
				mEdit.add(miUndo);
				mEdit.add(miRedo);
				mHelp.add(miAbout);
				
				miNew.setIcon(new ImageIcon("images/new.gif"));
				miOpen.setIcon(new ImageIcon("images/open.gif"));
				miPrint.setIcon(new ImageIcon("images/print.gif"));
				miCopy.setIcon(new ImageIcon("images/copy.gif"));
				miCut.setIcon(new ImageIcon("images/cut.gif"));
				miPaste.setIcon(new ImageIcon("images/paste.gif"));
				miSelectAll.setIcon(new ImageIcon("images/selectall.gif"));
				miUndo.setIcon(new ImageIcon("images/undo.gif"));
				miRedo.setIcon(new ImageIcon("images/redo.gif"));
				miAbout.setIcon(new ImageIcon("images/about.gif"));
				
				mFile.setMnemonic('F');
				mEdit.setMnemonic('E');
				mHelp.setMnemonic('H');
				miNew.setMnemonic('N');
				miOpen.setMnemonic('O');
				miPrint.setMnemonic('P');
				miCopy.setMnemonic('C');
				miCut.setMnemonic('X');
				miPaste.setMnemonic('V');
				miSelectAll.setMnemonic('A');
				miUndo.setMnemonic('Z');
				miRedo.setMnemonic('Y');
				miAbout.setMnemonic('A');

				miNew.setAccelerator(KeyStroke.getKeyStroke(KeyEvent.VK_N, ActionEvent.CTRL_MASK));
				miOpen.setAccelerator(KeyStroke.getKeyStroke(KeyEvent.VK_O, ActionEvent.CTRL_MASK));
				miPrint.setAccelerator(KeyStroke.getKeyStroke(KeyEvent.VK_P, ActionEvent.CTRL_MASK));
				miCopy.setAccelerator(KeyStroke.getKeyStroke(KeyEvent.VK_C, ActionEvent.CTRL_MASK));
				miCut.setAccelerator(KeyStroke.getKeyStroke(KeyEvent.VK_X, ActionEvent.CTRL_MASK));
				miPaste.setAccelerator(KeyStroke.getKeyStroke(KeyEvent.VK_P, ActionEvent.CTRL_MASK));
				miSelectAll.setAccelerator(KeyStroke.getKeyStroke(KeyEvent.VK_A, ActionEvent.CTRL_MASK));
				miUndo.setAccelerator(KeyStroke.getKeyStroke(KeyEvent.VK_Z, ActionEvent.CTRL_MASK));
				miRedo.setAccelerator(KeyStroke.getKeyStroke(KeyEvent.VK_Y, ActionEvent.CTRL_MASK));
				
				miNew.addActionListener(this);
				
				tbFile=new JToolBar("My Tool Bar");
				tbFile.setFloatable(true);
				
				btnNew=new JButton(new ImageIcon(getClass().getResource("images/btnnew.gif")));
				btnOpen=new JButton(new ImageIcon(getClass().getResource("images/btnopen.gif")));
				btnPrint=new JButton(new ImageIcon(getClass().getResource("images/btnprint.gif")));
				
				tbFile.add(btnNew);
				tbFile.add(btnOpen);
				tbFile.add(btnPrint);

				
				btnNew.setToolTipText("New");
				btnOpen.setToolTipText("Open");
				btnPrint.setToolTipText("Print");

				btnNew.setBorderPainted(false);
				btnOpen.setBorderPainted(false);
				btnPrint.setBorderPainted(false);

				add(tbFile,BorderLayout.NORTH);

				
				setVisible(true);
				setSize(500,500);
				setTitle("My Swing Application");
				setLocation(0,0);
				setResizable(false);
				setDefaultCloseOperation(EXIT_ON_CLOSE);
			}
		
		public void actionPerformed(ActionEvent ae)
			{
				if(ae.getSource()==miNew)
					{
						JOptionPane.showMessageDialog(null,"New File","Information",JOptionPane.INFORMATION_MESSAGE);
					}
			}
		
		public static void main(String args[])
			{
				setDefaultLookAndFeelDecorated(true);
				new EgSwing2();
			}
		
	}