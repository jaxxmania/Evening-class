class StudentInfo
	{
		String stdName;
		int age;
		char gender;
		
		public StudentInfo()
			{
				stdName="Ram";
				age=21;
				gender='M';
			}
			
		public void display()
			{
				System.out.println("Name="+stdName+"\nAge="+age+"\nGender="+gender);
			}
	}
	
public class EgConstructorWithoutParameter
	{
		public static void main(String args[])
			{
				StudentInfo std=new StudentInfo();
				std.display();
			}
	}
