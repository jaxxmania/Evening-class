abstract class StudentInfo
	{
		String stdname;
		int age;
		char gender;	
	}

class AcademicInfo extends StudentInfo
	{
		String standard;
		String faculty;
	}

class EgInheritancePhysicalInfo extends AcademicInfo
	{
		double height;
		double weight;
			
		
		public void assign()
			{
				stdname="Alex";
				age=20;
				gender='m';
				
				standard="Bachelor";
				faculty="Engineering";
				
				height=6.1;
				weight=65;
			}
		
		public void display()
			{
				System.out.println("Name="+stdname);
				System.out.println("Age="+age);
				System.out.println("Gender="+gender);
				System.out.println("Standard="+standard);
				System.out.println("Faculty="+faculty);
				System.out.println("Height="+height);
				System.out.println("Weight="+weight);
			}
		
		public static void main(String args[])
			{
				EgInheritancePhysicalInfo temp=new EgInheritancePhysicalInfo();
				temp.assign();
				temp.display();
			}
	}