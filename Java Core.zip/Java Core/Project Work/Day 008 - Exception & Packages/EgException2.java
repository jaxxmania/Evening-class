import java.io.*;

class EgException2
	{
		public static void main(String args[])
			{
				int a=10,b=0,i;
				int x[]=new int[5];
				
				BufferedReader bfr=new BufferedReader(new InputStreamReader(System.in));
				
				try
					{
						for(i=0;i<6;i++)
							x[i]=Integer.parseInt(bfr.readLine());
						
						int c=a/b;
						System.out.println("Result is:"+c);				
					}
				
				catch(ArithmeticException e)
					{
						System.out.println("Exception:"+e);
					}
				
				catch(ArrayIndexOutOfBoundsException e)
					{
						System.out.println("Expection:"+e);
					}
				
				catch(IOException e)
					{
						System.out.println("Exception:"+e);
					}
				
				finally
					{
						System.out.println("After Try & Catch");
					}
			}
	}