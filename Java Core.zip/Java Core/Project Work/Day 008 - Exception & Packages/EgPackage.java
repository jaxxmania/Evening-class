import P1.*;

public class EgPackage
	{
		public static void main(String args[])
			{
				Test temp=new Test();
				temp.show();
			}
	}