import java.awt.*;
import javax.swing.*;
import java.awt.event.*;

public class MyFrameExample extends Frame implements ActionListener
{
	Label lbluser,lblpass;
	TextField txtuser,txtpass;
	Button btnlogin;
	
	public MyFrameExample()
	{
		
		setLayout(null);
		
		lbluser=new Label("User Name");
		lblpass=new Label("Password");
		
		txtuser=new TextField(30);
		txtpass=new TextField(30);
		txtpass.setEchoChar('*');
		
		btnlogin=new Button("Login");
		
		add(lbluser);
		lbluser.setBounds(20,50,100,25);
		
		add(lblpass);
		lblpass.setBounds(20,80,100,25);
		
		add(txtuser);
		txtuser.setBounds(130,50,150,25);
		
		add(txtpass);
		txtpass.setBounds(130,80,150,25);
		
		add(btnlogin);
		btnlogin.setBounds(50,110,50,25);
		btnlogin.addActionListener(this);
	
		setVisible(true);
		setSize(300,150);
		setTitle("Login Application");
		setLocation(300,300);
		setResizable(false);
	}
	
	public void actionPerformed(ActionEvent ae)
	{
		
		if(ae.getSource()==btnlogin)
		{
			String struser="Alex";
			String strpwd="Alex123";

			if((struser.equals(txtuser.getText())) && (strpwd.equals(txtpass.getText())))
					
				//To call new Frame
				
						new MenuExample();
				
			
				//For messagebox
				//JOptionPane.showMessageDialog(null,"Login Successful","Information",JOptionPane.INFORMATION_MESSAGE);
			
			else
			
			JOptionPane.showMessageDialog(null,"Invalid Details","Information",JOptionPane.INFORMATION_MESSAGE);
		}	
	}
	
	public static void main(String args[])
	{
		new MyFrameExample();
	}
}