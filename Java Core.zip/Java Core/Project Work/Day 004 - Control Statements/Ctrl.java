public class Ctrl
{
public static void main(String args[])
{
int a=10;
int b=20;
int c=30;
if(a>b && a>c)
System.out.println("A is greatest."+a);
else if(b>c)
System.out.println("B is greatest"+b);
else
System.out.println("C="+c+" is greatest.");
}
}