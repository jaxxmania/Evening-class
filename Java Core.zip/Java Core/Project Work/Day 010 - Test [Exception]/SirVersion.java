class Employee
	{
		String name;
		int age,id;
		
		public void display()
			{
				System.out.println("\nID = "+id);
				System.out.println("Name = "+name);
				System.out.println("Age = "+age);
			}
		
	}

public class SirVersion
	{
		Employee emp[];
		
		public SirVersion()
			{
				emp=new Employee[3];
				
				for(int i=0;i<3;i++)
					emp[i]=new Employee();
					
				try
					{
						emp[0].id=1;
						emp[0].name="Harry";
						emp[0].age=25;
						
						emp[1].id=2;
						emp[1].name="Sally";
						emp[1].age=20;
						
						emp[2].id=2;
						emp[2].name="Sally";
						emp[2].age=20;
						
					//	emp[3].id=3;
					//	emp[3].name="John";
					//	emp[3].age=30;
												
					}
				
				catch(Exception e)
					{
						System.out.println("Duplicate Detected !!!	"+e);
					}
				
			}
		
		public void output()
			{
				for(int i=0;i<3;i++)
					emp[i].display();
			}
		
		public static void main (String args[])
			{
				SirVersion temp=new SirVersion();
				temp.output();
			}
	}