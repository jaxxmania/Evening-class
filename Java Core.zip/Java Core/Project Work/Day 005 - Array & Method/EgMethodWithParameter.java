import java.io.*;

class First
{
public void sum(int a,int b)
{
int c;
c=a+b;
System.out.println("Sum="+c);
}
}

public class EgMethodWithParameter
{
public static void main(String args[]) throws Exception
{
 BufferedReader bfr=new BufferedReader(new InputStreamReader(System.in));

int a,b;

a=Integer.parseInt(bfr.readLine());
b=Integer.parseInt(bfr.readLine());

First fs=new First();
fs.sum(a,b);
}
}