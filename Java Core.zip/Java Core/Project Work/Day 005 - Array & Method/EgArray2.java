import java.io.*;

public class EgArray2
{
 public static void main(String args[]) throws Exception
{
 BufferedReader bfr=new BufferedReader(new InputStreamReader(System.in));
int a[][]=new int[2][2];
int b[][]=new int[2][2];
int sum[][]=new int[2][2];

int i,j;

System.out.println("input first matrix:");

for(i=0;i<2;i++)
{
for(j=0;j<2;j++)
 a[i][j]=Integer.parseInt(bfr.readLine());
}

System.out.println("\ninput second matrix:");

for(i=0;i<2;i++)
{
for(j=0;j<2;j++)
 b[i][j]=Integer.parseInt(bfr.readLine());
}

System.out.println("\nsum:");

for(i=0;i<2;i++)
{
for(j=0;j<2;j++)
{
 sum[i][j]=a[i][j]+b[i][j];
 System.out.print(sum[i][j]+" ");
}
 System.out.println();
}
}
}