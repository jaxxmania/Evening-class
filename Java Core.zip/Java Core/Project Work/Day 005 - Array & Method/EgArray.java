import java.io.*;

public class EgArray
{
 public static void main(String args[]) throws Exception
{
 BufferedReader bfr=new BufferedReader(new InputStreamReader(System.in));
int a[]= new int[10];
int sum=0;
int i;

System.out.println("input ten numbers:");
for(i=0;i<10;i++)
{
 a[i]=Integer.parseInt(bfr.readLine());
sum+=a[i];
}
System.out.println("sum="+sum);
}
}