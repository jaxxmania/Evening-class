import javax.swing.*;

public class inputDemo extends JFrame
{
	public inputDemo()
	{
		String name=JOptionPane.showInputDialog(null, "Enter Name", "JOptionPaneDemo",JOptionPane.QUESTION_MESSAGE);
		JOptionPane.showMessageDialog(null,"Your Name is:"+name,"Information",JOptionPane.INFORMATION_MESSAGE);
		setVisible(true);
		setSize(200,200);
	
	}
	public static void main(String args[])
	{
		new inputDemo();
	}
}