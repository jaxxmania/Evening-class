import java.awt.*;
import javax.swing.*;
import java.awt.event.*;
import java.sql.*;

public class LoginDatabase extends Frame implements ActionListener
{
	Label lbluser,lblpass;
	TextField txtuser,txtpass;
	Button btnlogin;

	Connection con;
	PreparedStatement pstmt;
	ResultSet rs;

	public LoginDatabase()
		{

			setLayout(null);

			lbluser=new Label("User Name");
			lblpass=new Label("Password");

			txtuser=new TextField(30);
			txtpass=new TextField(30);
			txtpass.setEchoChar('*');

			btnlogin=new Button("Login");

			add(lbluser);
			lbluser.setBounds(20,50,100,25);

			add(lblpass);
			lblpass.setBounds(20,80,100,25);

			add(txtuser);
			txtuser.setBounds(130,50,150,25);

			add(txtpass);
			txtpass.setBounds(130,80,150,25);

			add(btnlogin);
			btnlogin.setBounds(50,110,50,25);
			btnlogin.addActionListener(this);

			setVisible(true);
			setSize(300,150);
			setTitle("Login Application");
			setLocation(300,300);
			setResizable(false);
		}

	public void actionPerformed(ActionEvent ae)
		{
			if(ae.getSource()==btnlogin)
			{
				try
					{
						Class.forName("sun.jdbc.odbc.JdbcOdbcDriver");
						con=DriverManager.getConnection("jdbc:odbc:EgConnector","sa","niit");

						pstmt=con.prepareStatement("select * from userLogin where username=? and password=?");
						pstmt.setString(1,txtuser.getText());
						pstmt.setString(2,txtpass.getText());
						rs=pstmt.executeQuery();

						if(rs.next())
							{
								new EgFrameMenu();
							}

						else
							{
								JOptionPane.showMessageDialog(null,"Invalid Details","Information",JOptionPane.INFORMATION_MESSAGE);
							}
					}

				catch(Exception e)
					{
					}

		}

	public static void main(String args[])
	{
		new LoginDatabase();
	}
}
