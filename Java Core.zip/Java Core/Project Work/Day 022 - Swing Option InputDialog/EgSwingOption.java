import java.awt.*;
import javax.swing.*;
import java.awt.event.*;
import java.sql.*;

public class EgSwingOption extends JFrame implements ActionListener
{
	JLabel lbluser,lblpass;
	JTextField txtuser;
	JPasswordField txtpass;
	JButton btnlogin,btnDbDriverName,btnDbDSN,btnDbUsername,btnDbPassword;
	
	Connection con;
	PreparedStatement pstmt;
	ResultSet rs;
		
	String dbDriverName,dbDSN,dbUsername,dbPassword;
		
	public EgSwingOption()
		{
			setLayout(null);
			
			lbluser=new JLabel("User Name");
			lblpass=new JLabel("Password");
		
			txtuser=new JTextField(30);
			
			txtpass=new JPasswordField(30);
			
			btnlogin=new JButton("Login");
			btnDbDriverName=new JButton("Set DB Driver");
			btnDbDSN=new JButton("Set DB DSN");
			btnDbUsername=new JButton("Set DB Username");
			btnDbPassword=new JButton("Set DB Password");
			
			add(lbluser);
			lbluser.setBounds(20,50,100,25);
		
			add(lblpass);
			lblpass.setBounds(20,80,100,25);
		
			add(txtuser);
			txtuser.setBounds(130,50,150,25);
		
			add(txtpass);
			txtpass.setBounds(130,80,150,25);
		
			add(btnlogin);
			btnlogin.setBounds(50,110,50,25);
			btnlogin.addActionListener(this);
	
			add(btnDbDriverName);
			btnDbDriverName.setBounds(20,140,100,25);
			btnDbDriverName.addActionListener(this);
			
			add(btnDbDSN);
			btnDbDSN.setBounds(20,170,100,25);
			btnDbDSN.addActionListener(this);
			
			add(btnDbUsername);
			btnDbUsername.setBounds(20,200,100,25);
			btnDbUsername.addActionListener(this);
			
			add(btnDbPassword);
			btnDbPassword.setBounds(20,230,100,25);
			btnDbPassword.addActionListener(this);
			
			setVisible(true);
			setSize(400,400);
			setTitle("Login Application");
			//setLocation(300,300);
			setResizable(false);
		}
	
	public void actionPerformed(ActionEvent ae)
		{
			if(ae.getSource()==btnlogin)
			{
				try
					{
						Class.forName(dbDriverName);
						con=DriverManager.getConnection(dbDSN,dbUsername,dbPassword);
					
						pstmt=con.prepareStatement("select * from userLogin where username=? and password=?");
						pstmt.setString(1,txtuser.getText());
						pstmt.setString(2,txtpass.getText());
						rs=pstmt.executeQuery();
				
						if(rs.next())
							{
								new EgFrameMenu();
							}
					
						else
							{
								JOptionPane.showMessageDialog(null,"Invalid Details","Information",JOptionPane.INFORMATION_MESSAGE);
							}
					}
			
				catch(Exception e)
					{
					}
			}
			
			if(ae.getSource()==btnDbDriverName)
				{
					dbDriverName=JOptionPane.showInputDialog(null, "Enter Database Driver Name", "JOptionPaneDemo",JOptionPane.QUESTION_MESSAGE);
				}
			
			if(ae.getSource()==btnDbDSN)
				{
					dbDSN=JOptionPane.showInputDialog(null, "Enter DSN Path", "JOptionPaneDemo",JOptionPane.QUESTION_MESSAGE);
				}
			
			if(ae.getSource()==btnDbUsername)
				{
					dbUsername=JOptionPane.showInputDialog(null, "Enter Database Username", "JOptionPaneDemo",JOptionPane.QUESTION_MESSAGE);
				}
			
			if(ae.getSource()==btnDbPassword)
				{
					dbPassword=JOptionPane.showInputDialog(null, "Enter Database Password", "JOptionPaneDemo",JOptionPane.QUESTION_MESSAGE);
				}
		}
	
	public static void main(String args[])
	{
		new EgSwingOption();
	}
}