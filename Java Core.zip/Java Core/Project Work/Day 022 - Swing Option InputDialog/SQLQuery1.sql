create database EgDatabase
use EgDatabase
create table userLogin(username varchar(25),password varchar(25))
insert into userLogin values('dd','12345')
insert into userLogin values('noxious','54321')
select * from userLogin
