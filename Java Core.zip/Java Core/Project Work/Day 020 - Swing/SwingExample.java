import javax.swing.*;
import java.awt.event.*;
import java.sql.*;

public class SwingExample extends JFrame implements ActionListener
{
	JLabel lbluser,lblpass;
	JTextField txtuser;
	JPasswordField jpf;
	JButton btnlogin;

	Connection con;
	PreparedStatement pstmt;
	ResultSet rs;
		
	public SwingExample()
	{
		setLayout(null);
		lbluser=new JLabel("User Name:");	
		lblpass=new JLabel("Password:");	

		txtuser=new JTextField(20);
		jpf=new JPasswordField(20);

		btnlogin=new JButton("Login");
	
		add(lbluser);
		lbluser.setBounds(20,30,100,25);
		add(txtuser);
		txtuser.setBounds(125,30,100,25);

		add(lblpass);
		lblpass.setBounds(20,60,100,25);

		add(jpf);
		jpf.setBounds(125,60,100,25);

		add(btnlogin);
		btnlogin.setBounds(75,90,100,25);
		btnlogin.addActionListener(this);
		
		setVisible(true);
		setSize(300,150);
		setTitle("User Login:");
		setLocation(250,250);
		setResizable(false);
		setDefaultCloseOperation(EXIT_ON_CLOSE);

	}
	
	public void actionPerformed(ActionEvent ae)
			{
				if(ae.getSource()==btnlogin)
					try
						{
							Class.forName("sun.jdbc.odbc.JdbcOdbcDriver");
							con=DriverManager.getConnection("jdbc:odbc:EgConnector","sa","niit");
					
							pstmt=con.prepareStatement("select * from userLogin where username=? and password=?");
							pstmt.setString(1,txtuser.getText());
							pstmt.setString(2,jpf.getText());
							rs=pstmt.executeQuery();
				
							if(rs.next())
								{
									new EgFrameMenu();
								}
			
							else
								{
									JOptionPane.showMessageDialog(null,"Invalid Details","Information",JOptionPane.INFORMATION_MESSAGE);
								}
						}
			
					catch(Exception e)
						{
							JOptionPane.showMessageDialog(null,"Error : "+e,"Exception Caught",JOptionPane.INFORMATION_MESSAGE);
						}
			}
	
	public static void main(String args[])
	{
		setDefaultLookAndFeelDecorated(true);
		new SwingExample();
	}

}