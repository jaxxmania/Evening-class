import javax.swing.*;
import java.awt.event.*;
import java.sql.*;

public class ModRecord extends JFrame implements ActionListener
{
	JLabel lblroll,lblfname,lbllname,lblfac,lblgen,lblage;
	JTextField txtfname,txtlname,txtage;
	JComboBox chgen,chfac,chroll;
	JButton btnsave,btngo;
	
	Connection con;
	PreparedStatement pstmt;
	Statement stmt;
	ResultSet rs;
	
	public ModRecord()
	{
		setLayout(null);
		
		btngo=new JButton("Go");
		lblroll=new JLabel("Roll No");
		lblfname=new JLabel("First Name");
		lbllname=new JLabel("Last Name");
		lblfac=new JLabel("Faculty");
		lblgen=new JLabel("Gender");
		lblage=new JLabel("Age");
		
		chroll=new JComboBox();
		txtfname=new JTextField(30);
		txtlname=new JTextField(30);
		txtage=new JTextField(30);
		
		chfac=new JComboBox();
		chgen=new JComboBox();
		
		chfac.addItem("Computer");
		chfac.addItem("Civil");
		chfac.addItem("Architecture");
		chfac.addItem("Electronics");
		
		chgen.addItem("Male");
		chgen.addItem("***");
		chgen.addItem("Female");
		
		
		btnsave=new JButton("Modify");
		
		add(lblroll);
		lblroll.setBounds(20,50,100,25);
		
		add(lblfname);
		lblfname.setBounds(20,80,100,25);
		
		add(lbllname);
		lbllname.setBounds(20,110,100,25);
		
		add(lblfac);
		lblfac.setBounds(20,140,100,25);
		
		add(lblgen);
		lblgen.setBounds(20,170,100,25);
		
		add(lblage);
		lblage.setBounds(20,200,100,25);
		
		add(chroll);
		chroll.setBounds(150,50,150,25);
		
		add(btngo);
		btngo.setBounds(320,50,100,25);
		
		add(txtfname);
		txtfname.setBounds(150,80,150,25);
		
		add(txtlname);
		txtlname.setBounds(150,110,150,25);
		
		add(txtage);
		txtage.setBounds(150,200,150,25);
		
		add(chfac);
		chfac.setBounds(150,140,150,25);
		
		add(chgen);
		chgen.setBounds(150,170,150,25);
		
		add(btnsave);
		
		btnsave.setBounds(50,250,75,25);
		btnsave.addActionListener(this);
		
		btngo.addActionListener(this);
		
		setVisible(true);
		setSize(500,575);
		setTitle("Modify Record");
		//setLocation(250,250);
		//setResizable(false);
		setDefaultCloseOperation(EXIT_ON_CLOSE);

		try
		{
			Class.forName("sun.jdbc.odbc.JdbcOdbcDriver");
			con=DriverManager.getConnection("Jdbc:odbc:EgConnector","sa","niit");
			stmt=con.createStatement();
			rs=stmt.executeQuery("select rollno from TblStdDetails");
			while(rs.next())
			{
				chroll.addItem(rs.getString(1));
			}
		}
		catch(Exception e)
		{
		}
		
	/*	addWindowListener(new WindowAdapter()
			{
				public void windowClosing(WindowEvent event)
					{
						System.exit(0);
					}
			}
		);	*/
	}

	public void actionPerformed(ActionEvent ae)
	{
		
		if(ae.getSource()==btngo)
		{
			try
			{
				Class.forName("sun.jdbc.odbc.JdbcOdbcDriver");
				con=DriverManager.getConnection("Jdbc:odbc:EgConnector","sa","niit");
				pstmt=con.prepareStatement("select * from TblStdDetails where rollno=?");
				pstmt.setString(1,chroll.getSelectedItem().toString());
				rs=pstmt.executeQuery();
				if(rs.next())
				{
					txtfname.setText(rs.getString(2));
					txtlname.setText(rs.getString(3));
					txtage.setText(rs.getString(4));
					
					//chfac.select(rs.getString(5).toString());
					
					//chgen.select(rs.getString(6).toString());
				}
			}
			catch(Exception e)
			{	
				JOptionPane.showMessageDialog(null,"ERROR:"+e,"Information",JOptionPane.INFORMATION_MESSAGE);
			}
		}	
		
		if(ae.getSource()==btnsave)
		{
			try
			{
				Class.forName("sun.jdbc.odbc.JdbcOdbcDriver");
				con=DriverManager.getConnection("Jdbc:odbc:EgConnector","sa","niit");
				pstmt=con.prepareStatement("update TblStdDetails set firstname=?,lastname=?,age=?,faculty=?,gender=? where rollno=?");
				pstmt.setString(1,txtfname.getText());
				pstmt.setString(2,txtlname.getText());
				pstmt.setString(3,txtage.getText());
				pstmt.setString(4,chfac.getSelectedItem().toString());
				pstmt.setString(5,chgen.getSelectedItem().toString());
				pstmt.setString(6,chroll.getSelectedItem().toString());
				pstmt.executeUpdate();
				JOptionPane.showMessageDialog(null,"Updated Successfully","Information",JOptionPane.INFORMATION_MESSAGE);
			}
			catch(Exception e)
			{	
				JOptionPane.showMessageDialog(null,"ERROR:"+e,"Information",JOptionPane.INFORMATION_MESSAGE);
			}
		
		}
	}
	public static void main (String args[])
{
		setDefaultLookAndFeelDecorated(true);
		new ModRecord();
		
}
}		