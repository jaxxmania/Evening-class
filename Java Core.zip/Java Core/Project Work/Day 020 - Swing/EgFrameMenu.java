import javax.swing.*;
import java.awt.event.*;

public class EgFrameMenu extends JFrame implements ActionListener
	{
		JMenuBar mb;
		JMenu mnu1,mnu2;
		JMenuItem mi1,mi2,mi3,mi4,mi5;
	
		public EgFrameMenu()
			{
				mb=new JMenuBar();
		
				mnu1=new JMenu("File");
				mnu2=new JMenu("Help");
				
				mi1=new JMenuItem("New Record");
				mi2=new JMenuItem("Modify Record");
				mi3=new JMenuItem("Delete Record");
				mi4=new JMenuItem("Exit");
				mi5=new JMenuItem("About");
				
				setJMenuBar(mb);
				mb.add(mnu1);
				mb.add(mnu2);
		
				mnu1.add(mi1);
				mnu1.add(mi2);
				mnu1.add(mi3);
				mnu1.add(mi4);
				mnu2.add(mi5);
				
				mi1.addActionListener(this);
				mi2.addActionListener(this);
				//mi3.addActionListener(this);
				mi4.addActionListener(this);
				mi5.addActionListener(this);
				
				setVisible(true);
				setSize(800,600);
				setTitle("My Demo Application");
				setLocation(0,0);
				setResizable(false);
				setDefaultCloseOperation(EXIT_ON_CLOSE);
				
			}
		
		public void actionPerformed(ActionEvent ae)
			{
				if(ae.getSource()==mi1)
					new NewRecord();
				
				if(ae.getSource()==mi2)
					new ModRecord();
				
				if(ae.getSource()==mi4)
					System.exit(0);
				
				if(ae.getSource()==mi5)
					JOptionPane.showMessageDialog(null,"Developed by DD","About",JOptionPane.INFORMATION_MESSAGE);
			}
		
		public static void main(String args[])
			{
				new EgFrameMenu();
			}
	}