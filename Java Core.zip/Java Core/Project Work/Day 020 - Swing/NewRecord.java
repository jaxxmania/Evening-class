import javax.swing.*;
import java.awt.event.*;
import java.sql.*;

	public class NewRecord extends JFrame implements ActionListener{
		JLabel lblname,lblpass,lblroll,lblfaculty,lblgender,lblage,lblcomment;
		JTextField txtname,txtpass,txtroll,txtage,/*txtgender,*/txtfaculty;
		JCheckBox c1,c2,c3;
		JTextArea tacomment;
		JButton btnsave, btnreset;
		JComboBox chgen;
		
		int result;
		
		Connection con;
		PreparedStatement pstmt;
		
	public NewRecord()
	{
		setLayout(null);
		
		lblname = new JLabel("Name :");
		lblpass = new JLabel("Password :");
		lblgender = new JLabel("Gender(m/f)");
		lblroll = new JLabel("Roll no:");
		lblfaculty = new JLabel("Faculty");
		lblage = new JLabel("Age:");
		lblcomment=new JLabel("Comment");
		
		chgen=new JComboBox();
		chgen.addItem("Male");
		chgen.addItem("Female");
			
		txtname = new JTextField(50);
		txtpass = new JTextField(50);
		txtroll = new JTextField(8);
		txtage = new JTextField(3);
		//txtgender = new TextField(1);
		txtfaculty = new JTextField(30);
						
		tacomment = new JTextArea("",30,30);
		
		btnsave = new JButton("Save");
		btnreset = new JButton("Reset");
		
		add(lblname);
		lblname.setBounds(20,50,80,25);
		add(txtname);
		txtname.setBounds(110,50,300,25);
		
		add(lblpass);
		lblpass.setBounds(20,80,80,25);
		add(txtpass);
		txtpass.setBounds(110,80,300,25);

		
		add(lblroll);
		lblroll.setBounds(20,110,80,25);
		add(txtroll);
		txtroll.setBounds(110,110,300,25);

		add(lblage);
		lblage.setBounds(20,140,80,25);
		add(txtage);
		txtage.setBounds(110,140,30,25);

		add(lblgender);
		lblgender.setBounds(20,170,80,25);
		/*add(txtgender);
		txtgender.setBounds(110,140,25,25);*/
		add(chgen);
		chgen.setBounds(110,170,100,25);
		

		add(lblfaculty);
		lblfaculty.setBounds(20,200	,80,25);
		add(txtfaculty);
		txtfaculty.setBounds(110,200,300,25);
		
		add(lblcomment);
		lblcomment.setBounds(20,240,70,25);
		add(tacomment);
		tacomment.setBounds(100,240,250,100);

		add(btnsave);
		btnsave.setBounds(100,350,75,30);
		btnsave.addActionListener(this);
		add(btnreset);
		btnreset.setBounds(180,350,75,30);

		
		setVisible(true);
		setSize(500,500);
		setTitle("New Record");
		//setLocation(250,250);
		setResizable(false);
		setDefaultCloseOperation(EXIT_ON_CLOSE);
	}
	
	public void actionPerformed(ActionEvent ae)
	{
		if(ae.getSource()==btnsave)
		{
			try
			{
				Class.forName("sun.jdbc.odbc.JdbcOdbcDriver");
				con=DriverManager.getConnection("jdbc:odbc:EgConnector","sa","niit");
				pstmt=con.prepareStatement("insert into userRecord values(?,?,?,?,?,?,?)");
				
				pstmt.setString(1,txtname.getText());
				pstmt.setString(2,txtpass.getText());
				pstmt.setString(3,txtroll.getText());
				pstmt.setString(4,txtage.getText());
				pstmt.setString(5,chgen.getSelectedItem().toString());
				pstmt.setString(6,txtfaculty.getText());
				pstmt.setString(7,tacomment.getText());
				
				result=pstmt.executeUpdate();
				if(result>0)
				{
					JOptionPane.showMessageDialog(null,"Saved Successfully","Information",JOptionPane.INFORMATION_MESSAGE);
				}
				else
				{
					JOptionPane.showMessageDialog(null,"Error while saving","Information",JOptionPane.INFORMATION_MESSAGE);
				}
			}
			catch(Exception e)
			{
				JOptionPane.showMessageDialog(null,"Error:"+e,"Information",JOptionPane.INFORMATION_MESSAGE);
			}
		}
	}
	
	public static void main(String args[]){
		new NewRecord();
	}
}
		