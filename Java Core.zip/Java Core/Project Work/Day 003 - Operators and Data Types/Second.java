class Second
{
public static viod mail(String args[])
{
int a=10;
int b=20;
int c=a+b;
System.out.println("Sum is"+c);
System.out.println(a+b);
System.out.println((a+b));
}
}